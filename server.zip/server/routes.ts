import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { registerChatRoutes } from "./replit_integrations/chat";
import { registerImageRoutes } from "./replit_integrations/image";
import { db, pool } from "./db";
import { openai } from "./replit_integrations/image/client"; // Re-using the client which has env vars set up
// Note: openai client from image/client is just a configured OpenAI instance, we can use it for chat too.

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Register integration routes
  registerChatRoutes(app);
  registerImageRoutes(app);

  // Seeding
  await storage.seedData();

  app.post(api.search.query.path, async (req, res) => {
    try {
      const { query } = req.body;

      // 1. Generate SQL from NL
      const systemPrompt = `You are a SQL expert. Convert the user's natural language query into a PostgreSQL SQL query.
      
      Schema:
      - employees (id, name, department_id, email, salary)
      - departments (id, name)
      - orders (id, customer_name, employee_id, order_total, order_date)
      - products (id, name, price)
      
      Relationships:
      - employees.department_id -> departments.id
      - orders.employee_id -> employees.id

      Rules:
      - Return ONLY the SQL query. No markdown, no explanation.
      - Use ILIKE for text searches if appropriate.
      - Be careful with SQL injection prevention (although this is a prototype).
      - If the query cannot be answered, return "SELECT 'I cannot answer that' as message".
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-5.1", // or gpt-4o
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: query }
        ],
      });

      let sqlQuery = response.choices[0].message.content || "";
      // Clean up markdown code blocks if any
      sqlQuery = sqlQuery.replace(/```sql/g, "").replace(/```/g, "").trim();

      console.log("Generated SQL:", sqlQuery);

      // 2. Execute SQL
      // Validate: Only SELECT statements allowed for safety in this prototype
      if (!sqlQuery.toLowerCase().startsWith("select")) {
        return res.status(400).json({ error: "Only SELECT queries are allowed." });
      }

      const result = await pool.query(sqlQuery);

      res.json({
        sql: sqlQuery,
        results: result.rows,
        explanation: "Generated via OpenAI"
      });

    } catch (error: any) {
      console.error("Search error:", error);
      res.status(500).json({ message: error.message || "Internal server error" });
    }
  });

  return httpServer;
}
