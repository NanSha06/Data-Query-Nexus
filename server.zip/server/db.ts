import "dotenv/config";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

/**
 * Ensure DATABASE_URL exists
 */
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is not set. Please define it in a .env file."
  );
}

/**
 * PostgreSQL connection pool
 */
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: false, // local postgres
});

/**
 * ✅ Drizzle ORM database instance
 * Used by storage.ts and other ORM-based files
 */
export const db = drizzle(pool);

/**
 * Optional health check
 */
export async function checkDbConnection() {
  const client = await pool.connect();
  try {
    await client.query("SELECT 1");
    console.log("✅ Database connected successfully");
  } finally {
    client.release();
  }
}
// Immediately check the database connection when this module is loaded
checkDbConnection().catch((err) => {
  console.error("❌ Database connection failed:", err);
});