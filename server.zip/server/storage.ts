import { users, type User, type InsertUser } from "@shared/schema";
import { departments, employees, products, orders } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Add more methods if needed for manual CRUD, but we might rely on raw SQL for the "Natural Language" part
  // Seeding methods
  seedData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    // We don't have users table in the schema I wrote in shared/schema.ts?
    // Wait, I overwrote shared/schema.ts. I didn't include users table. 
    // The template usually has users. I should have kept it or removed it from storage.ts interface.
    // I'll remove it from interface since I didn't define it in schema.
    return undefined; 
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    throw new Error("Not implemented");
  }

  async seedData(): Promise<void> {
    // Check if data exists
    const existingDepts = await db.select().from(departments);
    if (existingDepts.length > 0) return;

    // Seed Departments
    const depts = await db.insert(departments).values([
      { name: "Engineering" },
      { name: "HR" },
      { name: "Sales" },
      { name: "Marketing" }
    ]).returning();

    const engId = depts.find(d => d.name === "Engineering")?.id;
    const hrId = depts.find(d => d.name === "HR")?.id;
    const salesId = depts.find(d => d.name === "Sales")?.id;

    // Seed Employees
    const employeesData = [
      { name: "Alice Johnson", email: "alice@company.com", departmentId: engId, salary: "120000.00" },
      { name: "Bob Smith", email: "bob@company.com", departmentId: engId, salary: "115000.00" },
      { name: "Charlie Brown", email: "charlie@company.com", departmentId: hrId, salary: "75000.00" },
      { name: "Diana Prince", email: "diana@company.com", departmentId: salesId, salary: "95000.00" },
    ];
    const emps = await db.insert(employees).values(employeesData).returning();

    // Seed Products
    const productsData = [
      { name: "Laptop", price: "1200.00" },
      { name: "Mouse", price: "25.00" },
      { name: "Keyboard", price: "50.00" },
      { name: "Monitor", price: "300.00" },
    ];
    await db.insert(products).values(productsData);

    // Seed Orders
    const ordersData = [
      { customerName: "Acme Corp", employeeId: emps[0].id, orderTotal: "5000.00", orderDate: new Date().toISOString() },
      { customerName: "Globex", employeeId: emps[3].id, orderTotal: "8000.00", orderDate: new Date().toISOString() },
    ];
    await db.insert(orders).values(ordersData);
  }
}

export const storage = new DatabaseStorage();
