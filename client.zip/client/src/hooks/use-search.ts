import { useMutation } from "@tanstack/react-query";
import { api, type SearchResponse, type SearchRequest } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useSearch() {
  const { toast } = useToast();

  return useMutation<SearchResponse, Error, SearchRequest>({
    mutationFn: async (data) => {
      // Validate input using the shared schema if possible, or simple check
      if (!data.query.trim()) {
        throw new Error("Query cannot be empty");
      }

      const res = await fetch(api.search.query.path, {
        method: api.search.query.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const error = await res.json().catch(() => ({}));
        throw new Error(error.message || "Failed to perform search");
      }

      // Validate response with Zod schema from shared routes
      return api.search.query.responses[200].parse(await res.json());
    },
    onError: (error) => {
      toast({
        title: "Search Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
