import { useState } from "react";
import { useSearch } from "@/hooks/use-search";
import { SearchHero } from "@/components/SearchHero";
import { ResultsTable } from "@/components/ResultsTable";
import { SqlViewer } from "@/components/SqlViewer";
import { Database, ShieldCheck, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { mutate: search, isPending, data, error, reset } = useSearch();
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (query: string) => {
    setHasSearched(true);
    search({ query });
  };

  return (
    <div className="min-h-screen bg-slate-50/50">
      {/* Decorative background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] rounded-full bg-blue-100/50 blur-3xl opacity-60" />
        <div className="absolute top-[10%] -right-[10%] w-[40%] h-[40%] rounded-full bg-indigo-100/50 blur-3xl opacity-60" />
      </div>

      <header className="relative z-10 w-full border-b border-border/40 bg-white/60 backdrop-blur-xl sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-display font-bold text-xl text-slate-900">
            <div className="bg-primary/10 p-2 rounded-lg">
              <Database className="w-5 h-5 text-primary" />
            </div>
            <span>DataQuery<span className="text-primary">.ai</span></span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            <a href="#" className="hover:text-primary transition-colors">Documentation</a>
            <a href="#" className="hover:text-primary transition-colors">Schema</a>
            <a href="#" className="hover:text-primary transition-colors">Examples</a>
          </nav>
        </div>
      </header>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
        <SearchHero onSearch={handleSearch} isPending={isPending} />

        <div className="min-h-[400px]">
          {isPending && (
            <div className="w-full flex flex-col items-center justify-center py-20 animate-in fade-in zoom-in duration-500">
              <div className="relative w-20 h-20 mb-8">
                <div className="absolute inset-0 border-4 border-slate-200 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin"></div>
                <Zap className="absolute inset-0 m-auto w-8 h-8 text-primary animate-pulse" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">Generating Query...</h3>
              <p className="text-slate-500">Translating your question into SQL</p>
            </div>
          )}

          {!isPending && hasSearched && error && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-50 border border-red-200 rounded-xl p-6 text-center max-w-2xl mx-auto"
            >
              <div className="bg-red-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-lg font-semibold text-red-900 mb-2">Search Failed</h3>
              <p className="text-red-700">{error.message}</p>
              <button 
                onClick={() => reset()}
                className="mt-4 text-sm font-medium text-red-600 hover:text-red-800 underline"
              >
                Clear error
              </button>
            </motion.div>
          )}

          {!isPending && data && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-3">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold text-slate-900">Results</h2>
                    <span className="text-sm text-slate-500">
                      Found {data.results.length} records
                    </span>
                  </div>
                  
                  {data.sql && <SqlViewer sql={data.sql} />}
                  
                  <ResultsTable data={data.results} />
                  
                  {data.explanation && (
                    <div className="mt-6 p-4 bg-blue-50/50 border border-blue-100 rounded-lg text-sm text-slate-600">
                      <p><span className="font-semibold text-blue-700">Insight:</span> {data.explanation}</p>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </main>

      <footer className="border-t border-slate-200 bg-white py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-slate-500">
            © 2024 Natural Language Search Interface. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-sm text-slate-500">
            <span>Powered by OpenAI & PostgreSQL</span>
            <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
            <span>v1.0.0</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
