import { useState } from "react";
import { Search, Sparkles, Command } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

interface SearchHeroProps {
  onSearch: (query: string) => void;
  isPending: boolean;
}

export function SearchHero({ onSearch, isPending }: SearchHeroProps) {
  const [query, setQuery] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  const suggestions = [
    "Show me all employees in Engineering",
    "List products more expensive than $50",
    "Who handled the most orders last month?",
    "Total sales by department",
  ];

  return (
    <div className="w-full max-w-4xl mx-auto mb-12">
      <div className="text-center mb-10 space-y-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4" />
            <span>AI-Powered Database Analyst</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-slate-900 mb-4">
            Ask your data <span className="text-primary">anything</span>
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Convert natural language questions into powerful SQL queries instantly.
            Analyze employees, products, orders, and departments with ease.
          </p>
        </motion.div>
      </div>

      <motion.form 
        onSubmit={handleSubmit}
        className="relative max-w-2xl mx-auto"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.5 }}
      >
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className={`h-6 w-6 transition-colors ${isPending ? 'text-primary animate-pulse' : 'text-slate-400 group-focus-within:text-primary'}`} />
          </div>
          <input
            type="text"
            className="block w-full pl-12 pr-4 py-6 bg-white border-2 border-slate-200 rounded-2xl text-lg shadow-lg shadow-slate-200/50 placeholder:text-slate-400 focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-300"
            placeholder="Ask a question about your data..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={isPending}
          />
          <div className="absolute inset-y-2 right-2">
            <Button 
              type="submit" 
              disabled={isPending || !query.trim()}
              className="h-full px-6 rounded-xl font-semibold bg-primary hover:bg-primary/90 text-white shadow-md hover:shadow-lg transition-all"
            >
              {isPending ? "Analyzing..." : "Search"}
            </Button>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {suggestions.map((suggestion, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setQuery(suggestion);
                // Optional: auto-submit
                // onSearch(suggestion); 
              }}
              className="px-4 py-2 rounded-lg bg-white border border-slate-200 text-sm text-slate-600 hover:border-primary/50 hover:text-primary hover:bg-primary/5 transition-all duration-200 shadow-sm"
            >
              "{suggestion}"
            </button>
          ))}
        </div>
      </motion.form>
    </div>
  );
}
