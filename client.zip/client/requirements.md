## Packages
framer-motion | For smooth page transitions and UI animations
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
Integration with /api/search requires POST requests
Using "Inter" for UI and "JetBrains Mono" for SQL code blocks
